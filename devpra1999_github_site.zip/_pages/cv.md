---
layout: single
title: "CV"
permalink: /cv/
---

[Download my CV](../assets/Dev_Srivastava_CV.pdf){: .btn .btn--primary}
